import greenfoot.*;
import java.util.*;

/**
 * Write a description of class MundoTetris here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MundoTetris extends World
{
    static final char[] cores = new char[]{'I','J','L','O','S','T','Z'};
    GreenfootImage[] images;
    List<Peca> pecas;
    boolean inicializacao, finalizacao;
    int velocidade;
    int pontuacao;
    
    public MundoTetris()
    {    
        super(10, 20, 30);
        for (int i=0; i<cores.length; i++)
        {
       //     images[i] = new GreenfootImage(cores[i]+".png");
        }
        pecas = new ArrayList<Peca>();
        inicializacao = false;
        
        //addObject(new StatusPanel(), 1, 1);
    }
    
    public GreenfootImage getImage(char cor)
    {
        for (int i=0; i<cores.length; i++)
            if (cores[i]==cor)
                return images[i];
        return null;
    }
    
        public void addPeca(int x, int y, char cor)
    {
        Peca p = new Peca(cor);
        addObject(p, x, y);
    }
    
      public void addPecaExistente(Peca p)
    {
        pecas.add(p);
    }
    
     public boolean LocalOcupado(int x, int y)
    {
        if (x<0 || y<0 || x>=getWidth() || y>=getHeight())
            return false;
        for (Peca p: pecas)
            if (p.getX()==x && p.getY()==y)
                return false;
        return true;
    }
    
    public void Jogar()
    {
        for (Peca p: pecas)
            removeObject(p);
         //         to be continued
        }
        
        public void VerificarLinhas()
    {
        int[] c = new int[getHeight()];
        for (Peca p: pecas)
            c[p.getY()]++;
        int[] cnt = new int[getHeight()+1];
        cnt[getHeight()] = 0;
        for (int i = getHeight()-1; i>=0; i--)
            cnt[i] = cnt[i+1] + (c[i]==getWidth()?1:0);
        if (cnt[0]==0) return;
        List<Peca> removed = new ArrayList<Peca>();
        for (Peca p: pecas)
        {
            if (c[p.getY()]==getWidth())
            {
                removeObject(p);              
                removed.add(p);
            }
        }
        for (Peca p: removed)
            pecas.remove(p);
        for (Peca p: pecas)
            p.setLocation(p.getX(), p.getY()+cnt[p.getY()]);
        switch (cnt[0])
        {
            case 1: pontuacao+=100;
            break;
            case 2: pontuacao+=300;
            break;
            case 3: pontuacao+=600;
            break;
            case 4: pontuacao+=1200;
            break;
        }
        velocidade = Math.min(9, pontuacao/1000);
    }
    
      public boolean isFinalizacao()
    {
        return finalizacao;
    }
    
    public void act()
    {
        if (!inicializacao&&!finalizacao)
        {
            inicializacao = true;
            Jogar();
        }
    }
    
    public int getVelocidade()
    {
        return velocidade;
    }
    
    public int getPontuacao()
    {
        return pontuacao;
    }
}
