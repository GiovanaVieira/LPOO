import greenfoot.*;

/**
 * Write a description of class FimDeJogo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FimDeJogo extends Actor
{
    /**
     * Act - do whatever the FimDeJogo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if ("enter".equals(Greenfoot.getKey()))
        {
            ((MundoTetris)getWorld()).Jogar();
            getWorld().removeObject(this);
        }
    }    
    }    