import greenfoot.*;

/**
 * Write a description of class Pecas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Peca extends Actor

    {
    char cor;
    
    public Peca(char cor)
    {
        super();
        this.cor = cor;
    }
    
    public void addedToWorld(World world)
    {
        super.addedToWorld(world);
        setImage(getMyWorld().getImage(cor));
    }
    
    private MundoTetris getMyWorld()
    {
        return (MundoTetris)getWorld();
    }
    
     public void act()
    {
        /* xyq */
    }    
}