import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bloco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bloco extends Actor{
    char cor;
    //Aplica uma imagem para o bloco
    Bloco(char cor){
        super();
        this.cor = cor;
    }
    
    private MundoTetris retornaWorld()
    {
        return (MundoTetris)getWorld();
    }    
}
