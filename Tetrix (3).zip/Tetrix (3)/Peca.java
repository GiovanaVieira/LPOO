import greenfoot.*;
import java.util.*;

/**
 * Write a description of class Pecas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Peca extends Actor{
    private final int ORIENTACAODAPECA_01 = 1;
    private final int ORIENTACAODAPECA_02 = 2;
    private final int ORIENTACAODAPECA_03 = 3;
    private final int ORIENTACAODAPECA_04 = 4;
    MundoTetris world;
    Peca peca;
    
    //figure parameters
    int tamanho, centro, rotacao;
    int[][] matriz;
    char cor;
    int posicaoX, posicaoY;
    int rotacaoMaxima;
    boolean velocidadeMaxima;

    //init
    private Bloco[] bloco;
    
    //real-time
    int counter;

    private boolean blocoParado;
    
    public Peca(char cor)
    {
        super();
        this.cor = cor;
    }
    
    public void addedToWorld(World world)
    {
        super.addedToWorld(world);
        setImage(getMyWorld().getImage(cor));
    }
    
    private MundoTetris getMyWorld()
    {
        return (MundoTetris)getWorld();
    }
 
    //verifica quais teclas o usuário pressionou e faz uma ação definida
    public void act(){
        if(Greenfoot.isKeyDown("up")){
        
        } 
        if(Greenfoot.isKeyDown("down")){
            descerBloco();
        }
        if(Greenfoot.isKeyDown("left")){
            moverParaEsquerda();
        }
        if(Greenfoot.isKeyDown("right")){
            moverParaDireita();
        }
        if(Greenfoot.isKeyDown("space")){
            descerTudo();
        }
    }
    
    void criaPecaAleatoria(){
        int pecaAleatoria;
        pecaAleatoria = Greenfoot.getRandomNumber(7);
        
        switch(pecaAleatoria){
            case 1:
               matriz = new int[][] { {0, 1, 0},{0, 1, 0}, {1, 1, 0} };
                break;
            case 2:
                matriz = new int[][]{{0, 1, 0, 0},{0, 1, 0, 0},{0, 1, 0, 0},{0, 1, 0, 0}};
                break;
            case 3:
                matriz = new int[][]{{0, 0, 0},{0, 1, 1},{0, 1, 1}};
                break;
            case 4:
                matriz = new int[][]{ {0, 1, 0}, {0, 1, 0}, {0, 1, 1} };
                break;
            case 5:
                matriz = new int[][]{{0, 1, 0},{0, 1, 1},{0, 0, 1}};
                break;
            case 6:
                matriz = new int[][]{{0, 1, 0},{0, 1, 1},{0, 1, 0}};
                break;
            default:
                matriz = new int[][]{{0, 0, 1},{0, 1, 1},{0, 1, 0}};
        }
        
    }
    
    public Peca(char color, int[][] matrix, int maxRot){
        tamanho = matriz.length;
        centro = (tamanho-1)/2;
        posicaoX = 0;
        posicaoY = 0;
        rotacao = 0;
        this.cor = cor;
        this.matriz = matriz;
        this.rotacaoMaxima = rotacaoMaxima;       
    }
    
    boolean ladosLivres(int x, int y, int rotacao){
        return true;
    }
    
    //Movimenta a peca para a direita, em 1 coluna
    boolean moverParaDireita(){
        if (ladosLivres(posicaoX+1, posicaoY, rotacao))
        {    
            mudarDirecao(posicaoX+1, posicaoY);
            return true;
        } 
        return false; 
    }
    
    //Movimenta a peça para a esquerda, em 1 coluna
    boolean moverParaEsquerda(){
        if (ladosLivres(posicaoX-1, posicaoY, rotacao))
        {    
            mudarDirecao(posicaoX-1, posicaoY);
            return true;
        } 
        return false;
    }
    
    void mudarDirecao(int x, int y){
        posicaoX = x; posicaoY = y;
        if (bloco!=null)
            atualizarBloco();
        super.setLocation(posicaoX-centro, posicaoY-centro);
    }
    
    void atualizarBloco(){
        int k = 0;
        for (int i=0; i < tamanho; i++){
            for (int j=0; j < tamanho; j++){
                if (!ladosLivres(i, j, rotacao))
                {
                   bloco[k].setLocation(posicaoX+i-centro, posicaoY+j-centro);
                   k++;
                }
            }
        }
    }
    
    //Verifica se alguma linha do mundo foi preenchida com blocos
    void linhaCompletada(){
    
    }
    
    //Elimina uma linha completada por blocos no mundo
    void limparLinhaCompletada(){
    
    }
    
    //Caso a peça encontre uma bloco abaixo e não possa se movimentar, ela para.
    void paraPeca(){
        /*
        MundoTetris mundo;
        mundo.retornaMundoTetris();
        
        criaPecaAleatoria();
        //if(fimDoCenario(bloco) == true){
        
        //}
        */
    }
    
    //Deleta uma peça criada no Mundo
    void deletaPeca(){
        int auxiliar;
        for(auxiliar = 0; auxiliar < 4; auxiliar++){
            getWorld().removeObject(bloco[auxiliar]);
        }
        blocoParado = true;
    }
    
    //Verifica se o fim do mundo foi alcançado, se sim, cria outra peça.
    boolean fimDoCenario(Peca peca){
        world.retornaMundoTetris();
        java.util.List lista;
        
        for(int i = 0; i < 4; i++){
            lista = world.getObjectsAt(bloco[i].getX(),bloco[i].getY(), Bloco.class);
            
            if(lista.size() > 1){
                return true;
            }
        }
        
        return false;
    }
    
    //Verifica se  a linha abaixo do bloco está livre
    boolean blocoAbaixoLivre(int posicao){  
        world.retornaMundoTetris();
        java.util.List lista;
        lista = world.getObjectsAt(bloco[posicao].getX(), bloco[posicao].getY()+1, Actor.class);
        
        if(lista.size() == 0){
            return true;
        }
        
        Actor ator = (Actor)lista.get(0);
        for(int i = 0; i < 4; i++){
            if(i == posicao){
                continue;
            }
            else if(ator == bloco[i]){
                return true;
            }
        }
        
        return false;
    }
    
    public boolean descer(){
        for(int i = 0; i < 4; i++){
            if(blocoAbaixoLivre(i) == false){
                linhaCompletada();
                paraPeca();
                return false;
            }
        }
        
        for(int i = 0; i < 4; i++){
            bloco[i].setLocation(bloco[i].getX(), bloco[i].getY()+1);
        }
        return true;
    }
    
    public void descerBloco(){
        descer();
    }
    
    public void descerTudo(){
        while(descer() == true){
            ;
        }
    }
    
    boolean fimDoCenario(){
        return false;
    }
    
    public void pararPeca(){
        world.retornaMundoTetris();
        world.removeObject(this);
        blocoParado = true;
        
        criaPecaAleatoria();
        if(fimDoCenario()){
            peca.deletaPeca();
            world.isFinalizacao();
        }
    }   
}