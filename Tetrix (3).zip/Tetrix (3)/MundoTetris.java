import greenfoot.*;
import java.util.*;

/**
 * Write a description of class MundoTetris here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MundoTetris extends World
{
    static final char[] cores = new char[]{'I','J','L','O','S','T','Z'};
    MundoTetris world;
    GreenfootImage[] images;
    List<Bloco> blocos;
    boolean inicializacao, finalizacao;
    int velocidade;
    int pontuacao;
    
    public MundoTetris()
    {    
        super(10, 20, 30);
        for (int i=0; i<cores.length; i++)
        {
       //     images[i] = new GreenfootImage(cores[i]+".png");
        }
        blocos = new ArrayList<Bloco>();
        inicializacao = false;
        
        //addObject(new StatusPanel(), 1, 1);
    }
    
    public GreenfootImage getImage(char cor)
    {
        for (int i=0; i<cores.length; i++)
            if (cores[i]==cor)
                return images[i];
        return null;
    }
    
        public void adicionaBloco(int x, int y, char cor)
    {
        Bloco bloco = new Bloco(cor);
        addObject(bloco, x, y);
        blocos.add(bloco);
    }
    
      public void adicionaBlocoExistente(Bloco bloco)
    {
        blocos.add(bloco);
    }
    
     public boolean LocalOcupado(int x, int y)
    {
        if (x<0 || y<0 || x>=getWidth() || y>=getHeight())
            return false;
        for (Bloco bloco: blocos)
            if (bloco.getX()==x && bloco.getY()==y)
                return false;
        return true;
    }
    
    public void Jogar()
    {
        for (Bloco bloco: blocos)
            removeObject(bloco);
         //         to be continued
        }
        
        public void VerificarLinhas()
    {
        int[] c = new int[getHeight()];
        for (Bloco bloco: blocos)
            c[bloco.getY()]++;
        int[] cnt = new int[getHeight()+1];
        cnt[getHeight()] = 0;
        for (int i = getHeight()-1; i>=0; i--)
            cnt[i] = cnt[i+1] + (c[i]==getWidth()?1:0);
        if (cnt[0]==0) return;
        List<Bloco> removed = new ArrayList<Bloco>();
        for (Bloco bloco: blocos)
        {
            if (c[bloco.getY()]==getWidth())
            {
                removeObject(bloco);              
                removed.add(bloco);
            }
        }
        for (Bloco bloco: removed)
            blocos.remove(bloco);
        for (Bloco bloco: blocos)
            bloco.setLocation(bloco.getX(), bloco.getY()+cnt[bloco.getY()]);
        switch (cnt[0])
        {
            case 1: pontuacao+=100;
            break;
            case 2: pontuacao+=300;
            break;
            case 3: pontuacao+=600;
            break;
            case 4: pontuacao+=1200;
            break;
        }
        velocidade = Math.min(9, pontuacao/1000);
    }
    
      public boolean isFinalizacao()
    {
        return finalizacao = true;
    }
    
    public void act()
    {
        if (!inicializacao && !finalizacao)
        {
            inicializacao = true;
            finalizacao = false;
            Jogar();
        }
    }
    
    public int getVelocidade()
    {
        return velocidade;
    }
    
    public int getPontuacao()
    {
        return pontuacao;
    }
    
    public MundoTetris retornaMundoTetris(){
        return world;
    }
}
